import 'package:flutter/material.dart';
import 'package:flutter_carplay/flutter_carplay.dart';

import '../../app/app_config.dart';
import '../../services/car_integration_service.dart';
import '../../services/spotify_service.dart';
import '../music/music_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    required this.carIntegration,
    required this.spotify,
    super.key,
  });

  final CarIntegrationService carIntegration;
  final SpotifyService spotify;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  bool _refreshing = false;

  Future<void> _refreshVehicle() async {
    if (_refreshing) return;
    setState(() => _refreshing = true);
    try {
      await widget.carIntegration.refreshVehicleDisplay();
      if (widget.spotify.authenticated) {
        await widget.spotify.refreshNowPlaying();
      }
    } finally {
      if (mounted) setState(() => _refreshing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F8),
      body: SafeArea(
        bottom: false,
        child: ValueListenableBuilder<ConnectionStatusTypes>(
          valueListenable: widget.carIntegration.connectionStatus,
          builder: (context, status, _) {
            return Column(
              children: <Widget>[
                Expanded(
                  child: IndexedStack(
                    index: _selectedIndex,
                    children: <Widget>[
                      _DriveDashboard(
                        status: status,
                        refreshing: _refreshing,
                        onRefresh: _refreshVehicle,
                        spotify: widget.spotify,
                        onOpenMusic: () => setState(() => _selectedIndex = 1),
                      ),
                      MusicScreen(spotify: widget.spotify),
                      const _CollectionPage(
                        title: 'Saved',
                        subtitle: 'Places ready for the road',
                        icon: Icons.star_rounded,
                        emptyTitle: 'No saved places yet',
                        emptyBody:
                            'Saved destinations will appear here and sync to your vehicle display.',
                      ),
                      const _CollectionPage(
                        title: 'Recent',
                        subtitle: 'Your latest driving activity',
                        icon: Icons.history_rounded,
                        emptyTitle: 'No recent trips yet',
                        emptyBody:
                            'Recent destinations and trip activity will appear here automatically.',
                      ),
                      _SettingsPage(spotify: widget.spotify),
                    ],
                  ),
                ),
                NavigationBar(
                  selectedIndex: _selectedIndex,
                  height: 70,
                  backgroundColor: Colors.white,
                  indicatorColor: const Color(0xFFE8EBEF),
                  onDestinationSelected: (value) {
                    setState(() => _selectedIndex = value);
                  },
                  destinations: const <NavigationDestination>[
                    NavigationDestination(
                      icon: Icon(Icons.directions_car_outlined),
                      selectedIcon: Icon(Icons.directions_car_rounded),
                      label: 'Drive',
                    ),
                    NavigationDestination(
                      icon: Icon(Icons.music_note_outlined),
                      selectedIcon: Icon(Icons.music_note_rounded),
                      label: 'Music',
                    ),
                    NavigationDestination(
                      icon: Icon(Icons.star_outline_rounded),
                      selectedIcon: Icon(Icons.star_rounded),
                      label: 'Saved',
                    ),
                    NavigationDestination(
                      icon: Icon(Icons.history_rounded),
                      label: 'Recent',
                    ),
                    NavigationDestination(
                      icon: Icon(Icons.settings_outlined),
                      selectedIcon: Icon(Icons.settings_rounded),
                      label: 'Settings',
                    ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _DriveDashboard extends StatelessWidget {
  const _DriveDashboard({
    required this.status,
    required this.refreshing,
    required this.onRefresh,
    required this.spotify,
    required this.onOpenMusic,
  });

  final ConnectionStatusTypes status;
  final bool refreshing;
  final Future<void> Function() onRefresh;
  final SpotifyService spotify;
  final VoidCallback onOpenMusic;

  @override
  Widget build(BuildContext context) {
    final connected = status == ConnectionStatusTypes.connected ||
        status == ConnectionStatusTypes.background;
    final statusLabel = switch (status) {
      ConnectionStatusTypes.connected => 'Vehicle connected',
      ConnectionStatusTypes.background => 'Connected in background',
      ConnectionStatusTypes.disconnected => 'Vehicle disconnected',
      ConnectionStatusTypes.unknown => 'Ready to connect',
    };

    return AnimatedBuilder(
      animation: spotify,
      builder: (context, _) {
        return RefreshIndicator(
          onRefresh: onRefresh,
          child: CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            slivers: <Widget>[
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(22, 18, 22, 8),
                sliver: SliverToBoxAdapter(
                  child: Row(
                    children: <Widget>[
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: const Color(0xFF111827),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(
                          Icons.route_rounded,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              AppConfig.appName,
                              style: TextStyle(
                                color: Color(0xFF101317),
                                fontSize: 21,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -0.5,
                              ),
                            ),
                            SizedBox(height: 1),
                            Text(
                              'Drive connected. Keep it simple.',
                              style: TextStyle(
                                color: Color(0xFF747C89),
                                fontSize: 12.5,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(13),
                          border: Border.all(color: const Color(0xFFE5E9EE)),
                        ),
                        child: const Icon(
                          Icons.person_outline_rounded,
                          color: Color(0xFF2D3440),
                          size: 21,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(22, 10, 22, 0),
                sliver: SliverToBoxAdapter(
                  child: _ConnectionHero(
                    connected: connected,
                    statusLabel: statusLabel,
                    refreshing: refreshing,
                    onRefresh: onRefresh,
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(22, 20, 22, 0),
                sliver: SliverToBoxAdapter(
                  child: GestureDetector(
                    onTap: onOpenMusic,
                    child: spotify.authenticated
                        ? SpotifyNowPlayingCard(spotify: spotify)
                        : _SpotifyDashboardPrompt(
                            configured: spotify.configured,
                            onTap: onOpenMusic,
                          ),
                  ),
                ),
              ),
              const SliverPadding(
                padding: EdgeInsets.fromLTRB(22, 24, 22, 10),
                sliver: SliverToBoxAdapter(
                  child: _SectionTitle(
                    title: 'Vehicle systems',
                    action: '2 services',
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 22),
                sliver: SliverToBoxAdapter(
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: _PlatformCard(
                          icon: Icons.apple,
                          title: 'CarPlay',
                          subtitle: connected ? 'Available' : 'Ready',
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _PlatformCard(
                          icon: Icons.android,
                          title: 'Android Auto',
                          subtitle: connected ? 'Available' : 'Ready',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SliverPadding(
                padding: EdgeInsets.fromLTRB(22, 24, 22, 10),
                sliver: SliverToBoxAdapter(
                  child: _SectionTitle(title: 'Drive library'),
                ),
              ),
              const SliverPadding(
                padding: EdgeInsets.fromLTRB(22, 0, 22, 30),
                sliver: SliverToBoxAdapter(
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: _MetricCard(
                          label: 'Saved',
                          value: '0',
                          icon: Icons.star_outline_rounded,
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: _MetricCard(
                          label: 'Recent',
                          value: '0',
                          icon: Icons.history_rounded,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ConnectionHero extends StatelessWidget {
  const _ConnectionHero({
    required this.connected,
    required this.statusLabel,
    required this.refreshing,
    required this.onRefresh,
  });

  final bool connected;
  final String statusLabel;
  final bool refreshing;
  final Future<void> Function() onRefresh;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: <Color>[Color(0xFF111827), Color(0xFF202938)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: Colors.white.withValues(alpha: 0.10)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      width: 7,
                      height: 7,
                      decoration: BoxDecoration(
                        color: connected
                            ? const Color(0xFF66E3A4)
                            : const Color(0xFF9EA7B5),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 7),
                    Text(
                      statusLabel,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              const Icon(
                Icons.directions_car_filled_rounded,
                color: Color(0xFFCBD3DE),
                size: 31,
              ),
            ],
          ),
          const SizedBox(height: 27),
          const Text(
            'Your drive,\none tap away.',
            style: TextStyle(
              color: Colors.white,
              fontSize: 32,
              height: 1.03,
              fontWeight: FontWeight.w900,
              letterSpacing: -1.0,
            ),
          ),
          const SizedBox(height: 13),
          const Text(
            'Keep vehicle content and music state ready before you start driving.',
            style: TextStyle(
              color: Color(0xFFB8C1CE),
              fontSize: 12.5,
              height: 1.45,
            ),
          ),
          const SizedBox(height: 22),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: refreshing ? null : () => onRefresh(),
              style: FilledButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: const Color(0xFF111827),
                minimumSize: const Size.fromHeight(50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              icon: refreshing
                  ? const SizedBox(
                      width: 17,
                      height: 17,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.sync_rounded, size: 19),
              label: const Text(
                'Refresh vehicle display',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SpotifyDashboardPrompt extends StatelessWidget {
  const _SpotifyDashboardPrompt({
    required this.configured,
    required this.onTap,
  });

  final bool configured;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE4E8ED)),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 48,
            height: 48,
            decoration: const BoxDecoration(
              color: Color(0xFF1ED760),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.graphic_eq_rounded, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text(
                  'Spotify',
                  style: TextStyle(
                    color: Color(0xFF1F252D),
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  configured
                      ? 'Connect your account for Now Playing'
                      : 'Developer setup required before sign-in',
                  style: const TextStyle(
                    color: Color(0xFF7C8592),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: onTap,
            icon: const Icon(Icons.chevron_right_rounded),
          ),
        ],
      ),
    );
  }
}

class _PlatformCard extends StatelessWidget {
  const _PlatformCard({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE7EAEE)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, color: const Color(0xFF1D232B), size: 26),
          const SizedBox(height: 20),
          Text(
            title,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            style: const TextStyle(
              color: Color(0xFF858E9A),
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: const Color(0xFFE9EDF1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  label,
                  style: const TextStyle(
                    color: Color(0xFF737D89),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          Icon(icon, color: const Color(0xFF7F8995)),
        ],
      ),
    );
  }
}

class _CollectionPage extends StatelessWidget {
  const _CollectionPage({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.emptyTitle,
    required this.emptyBody,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final String emptyTitle;
  final String emptyBody;

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: <Widget>[
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(22, 20, 22, 0),
          sliver: SliverToBoxAdapter(
            child: _PageHeader(title: title, subtitle: subtitle),
          ),
        ),
        SliverFillRemaining(
          hasScrollBody: false,
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Container(
                    width: 74,
                    height: 74,
                    decoration: const BoxDecoration(
                      color: Color(0xFFE5E9EE),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(icon, size: 34, color: const Color(0xFF626C78)),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    emptyTitle,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    emptyBody,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFF7C8591),
                      fontSize: 12.5,
                      height: 1.45,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _SettingsPage extends StatelessWidget {
  const _SettingsPage({required this.spotify});

  final SpotifyService spotify;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: spotify,
      builder: (context, _) {
        return ListView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(22, 20, 22, 30),
          children: <Widget>[
            const _PageHeader(
              title: 'Settings',
              subtitle: 'Accounts and vehicle connections',
            ),
            const SizedBox(height: 22),
            _SettingsCard(
              icon: Icons.graphic_eq_rounded,
              iconBackground: const Color(0xFF1ED760),
              title: 'Spotify',
              subtitle: spotify.authenticated
                  ? spotify.profile?.displayName ?? 'Connected'
                  : spotify.configured
                      ? 'Ready to connect'
                      : 'Client ID not configured',
              trailing: spotify.authenticated
                  ? TextButton(
                      onPressed: spotify.signOut,
                      child: const Text('Disconnect'),
                    )
                  : FilledButton(
                      onPressed: spotify.busy ? null : spotify.signIn,
                      child: const Text('Connect'),
                    ),
            ),
            const SizedBox(height: 10),
            const _SettingsCard(
              icon: Icons.apple,
              title: 'CarPlay',
              subtitle: 'Vehicle template bridge enabled',
            ),
            const SizedBox(height: 10),
            const _SettingsCard(
              icon: Icons.android,
              title: 'Android Auto',
              subtitle: 'Vehicle template bridge enabled',
            ),
            const SizedBox(height: 22),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFE9EDF1),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Text(
                'Spotify sign-in must be completed on the phone. SC Drive only reads account-approved playback metadata and does not embed a Spotify Client Secret in the APK.',
                style: TextStyle(
                  color: Color(0xFF626C78),
                  fontSize: 11.5,
                  height: 1.45,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _SettingsCard extends StatelessWidget {
  const _SettingsCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.iconBackground = Colors.white,
    this.trailing,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color iconBackground;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE7EAEE)),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: iconBackground,
              borderRadius: BorderRadius.circular(13),
            ),
            child: Icon(icon, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF808995),
                    fontSize: 11.5,
                  ),
                ),
              ],
            ),
          ),
          if (trailing != null) ...<Widget>[
            const SizedBox(width: 8),
            trailing!,
          ],
        ],
      ),
    );
  }
}

class _PageHeader extends StatelessWidget {
  const _PageHeader({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          title,
          style: const TextStyle(
            color: Color(0xFF11151A),
            fontSize: 29,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.8,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          subtitle,
          style: const TextStyle(
            color: Color(0xFF7A8390),
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, this.action});

  final String title;
  final String? action;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: Color(0xFF252B33),
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        if (action != null)
          Text(
            action!,
            style: const TextStyle(
              color: Color(0xFF929AA5),
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
      ],
    );
  }
}
