class AppConfig {
  const AppConfig._();

  static const String appName = 'SC Drive';
  static const String appSubtitle = 'Android head-unit driver dashboard with live weather';
  static const String packageName = 'sc_drive';
  static const String applicationId = 'com.scdeport.scdrive';

  /// Public Spotify Client ID. Do not place a Client Secret in a mobile app.
  /// Build with: --dart-define=SPOTIFY_CLIENT_ID=your_client_id
  static const String spotifyClientId = String.fromEnvironment(
    'SPOTIFY_CLIENT_ID',
    defaultValue: '',
  );

  static const String spotifyRedirectUri = 'scdrive-login://callback';
  static const String spotifyRedirectScheme = 'scdrive-login';

  static bool get spotifyConfigured => spotifyClientId.trim().isNotEmpty;
}
