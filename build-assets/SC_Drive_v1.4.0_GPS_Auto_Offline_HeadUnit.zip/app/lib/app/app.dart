import 'dart:async';

import 'package:flutter/material.dart';

import '../features/head_unit/head_unit_screen.dart';
import '../features/home/home_screen.dart';
import '../services/car_integration_service.dart';
import '../services/drive_telemetry_service.dart';
import '../services/head_unit_platform_service.dart';
import '../services/spotify_service.dart';
import '../services/weather_service.dart';
import 'app_config.dart';

class ScDriveApp extends StatefulWidget {
  const ScDriveApp({super.key});

  @override
  State<ScDriveApp> createState() => _ScDriveAppState();
}

class _ScDriveAppState extends State<ScDriveApp> with WidgetsBindingObserver {
  late final SpotifyService _spotify;
  late final CarIntegrationService _carIntegration;
  late final DriveTelemetryService _telemetry;
  late final HeadUnitPlatformService _headUnitPlatform;
  late final WeatherService _weather;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _spotify = SpotifyService();
    _carIntegration = CarIntegrationService(spotifyService: _spotify);
    _telemetry = DriveTelemetryService();
    _weather = WeatherService(telemetry: _telemetry);
    _headUnitPlatform = HeadUnitPlatformService();
    unawaited(_spotify.initialize());
    unawaited(_carIntegration.initialize());
    unawaited(_telemetry.initialize());
    unawaited(_weather.initialize());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(_telemetry.resume());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _weather.dispose();
    _telemetry.dispose();
    _carIntegration.dispose();
    _spotify.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF111827),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF4F6F8),
      ),
      home: LayoutBuilder(
        builder: (context, constraints) {
          final headUnit = constraints.maxWidth >= 800 &&
              constraints.maxWidth > constraints.maxHeight;
          if (headUnit) {
            return HeadUnitScreen(
              spotify: _spotify,
              telemetry: _telemetry,
              platform: _headUnitPlatform,
              weather: _weather,
            );
          }
          return HomeScreen(
            carIntegration: _carIntegration,
            spotify: _spotify,
          );
        },
      ),
    );
  }
}
